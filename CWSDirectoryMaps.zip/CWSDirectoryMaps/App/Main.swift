//
//  Map.swift
//  CWSDirectoryMaps
//
//  Created by Steven Gonawan on 27/08/25.
//


//
//  Map_Pathfinding_TestApp.swift
//  Map Pathfinding Test
//
//  Created by Steven Gonawan on 26/08/25.
//

import SwiftUI

@main
struct Main: App {
    var body: some Scene {
        WindowGroup {
            PathfindingView()
        }
    }
}
